// Google Sheets configuration
const SHEETS_CONFIG = {
    // Replace with your Google Apps Script Web App URL
    SCRIPT_URL: 'https://docs.google.com/spreadsheets/d/1MKLb7jCbBxRchf-fmnbslyQw-2AakQckuLPvZqOawpk/edit?gid=0#gid=0',
    
    // Sheet names for different forms
    CONTACT_SHEET: 'Contact_Forms',
    ENROLLMENT_SHEET: 'Enrollments'
};

// Function to submit data to Google Sheets
async function submitToSheets(data, sheetType) {
    try {
        const response = await fetch(SHEETS_CONFIG.SCRIPT_URL, {
            method: 'POST',
            mode: 'no-cors',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                sheet: sheetType,
                data: data
            })
        });
        
        return { success: true };
    } catch (error) {
        console.error('Error submitting to sheets:', error);
        return { success: false, error: error.message };
    }
}