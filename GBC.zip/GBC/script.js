// Loading Screen
window.addEventListener('load', function() {
    const loader = document.getElementById('loader');
    setTimeout(() => {
        loader.style.opacity = '0';
        setTimeout(() => {
            loader.style.display = 'none';
        }, 500);
    }, 1500);
});

// Mobile Navigation
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Smooth Scrolling
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Header scroll effect
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.background = 'rgba(255, 255, 255, 0.98)';
        header.style.boxShadow = '0 2px 30px rgba(0, 0, 0, 0.15)';
    } else {
        header.style.background = 'rgba(255, 255, 255, 0.95)';
        header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    }
});

// Counter Animation
function animateCounters() {
    const counters = document.querySelectorAll('#students-count, #success-rate, #years-exp, #top-ranks');
    const targets = [5000, 95, 15, 500];
    
    counters.forEach((counter, index) => {
        const target = targets[index];
        const increment = target / 100;
        let current = 0;
        
        const updateCounter = () => {
            if (current < target) {
                current += increment;
                if (index === 1) { // Success rate
                    counter.textContent = Math.ceil(current) + '%';
                } else if (index === 2) { // Years
                    counter.textContent = Math.ceil(current) + '+';
                } else {
                    counter.textContent = Math.ceil(current) + '+';
                }
                setTimeout(updateCounter, 20);
            } else {
                if (index === 1) {
                    counter.textContent = target + '%';
                } else {
                    counter.textContent = target + '+';
                }
            }
        };
        updateCounter();
    });
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
            
            // Trigger counter animation when stats section is visible
            if (entry.target.classList.contains('stats')) {
                animateCounters();
            }
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.feature-card, .course-card, .faculty-card, .achievement-item, .stats');
    animatedElements.forEach(el => observer.observe(el));
});

// FAQ Functionality
document.addEventListener('DOMContentLoaded', () => {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all FAQ items
            faqItems.forEach(faq => faq.classList.remove('active'));
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
});

// Testimonial Slider
let currentTestimonial = 0;
const testimonials = document.querySelectorAll('.testimonial');

function showTestimonial(index) {
    testimonials.forEach(testimonial => testimonial.classList.remove('active'));
    testimonials[index].classList.add('active');
}

function nextTestimonial() {
    currentTestimonial = (currentTestimonial + 1) % testimonials.length;
    showTestimonial(currentTestimonial);
}

// Auto-rotate testimonials
setInterval(nextTestimonial, 5000);

// Modal Functionality
const modal = document.getElementById('modal');
const modalBody = document.getElementById('modal-body');
const closeModal = document.querySelector('.close');

function openModal(type) {
    let content = '';
    
    switch(type) {
        case 'demo':
            content = `
                <h2>Book Free Demo Class</h2>
                <form class="modal-form">
                    <input type="text" placeholder="Student Name" required>
                    <input type="email" placeholder="Email Address" required>
                    <input type="tel" placeholder="Phone Number" required>
                    <select required>
                        <option value="">Select Course</option>
                        <option value="neet">NEET Preparation</option>
                        <option value="jee">JEE Preparation</option>
                        <option value="kcet">KCET Preparation</option>
                        <option value="academic">Academic Coaching</option>
                    </select>
                    <select required>
                        <option value="">Preferred Time</option>
                        <option value="morning">Morning (9 AM - 12 PM)</option>
                        <option value="afternoon">Afternoon (2 PM - 5 PM)</option>
                        <option value="evening">Evening (6 PM - 8 PM)</option>
                    </select>
                    <button type="submit" class="btn-submit">Book Demo</button>
                </form>
            `;
            break;
        case 'enroll':
            content = `
                <h2>Enroll Now</h2>
                <form class="modal-form">
                    <input type="text" placeholder="Student Name" required>
                    <input type="email" placeholder="Email Address" required>
                    <input type="tel" placeholder="Phone Number" required>
                    <input type="text" placeholder="Parent Name" required>
                    <select required>
                        <option value="">Select Course</option>
                        <option value="neet">NEET Preparation - ₹45,000/year</option>
                        <option value="jee">JEE Preparation - ₹50,000/year</option>
                        <option value="kcet">KCET Preparation - ₹35,000/year</option>
                        <option value="academic">Academic Coaching - ₹25,000/year</option>
                    </select>
                    <select required>
                        <option value="">Current Class</option>
                        <option value="8">Class 8</option>
                        <option value="9">Class 9</option>
                        <option value="10">Class 10</option>
                        <option value="11">Class 11</option>
                        <option value="12">Class 12</option>
                        <option value="12pass">12th Pass</option>
                    </select>
                    <textarea placeholder="Any specific requirements or questions?" rows="3"></textarea>
                    <button type="submit" class="btn-submit">Submit Application</button>
                </form>
            `;
            break;
        case 'neet':
            content = `
                <h2>NEET Preparation Course</h2>
                <div class="course-modal-content">
                    <h3>Course Overview</h3>
                    <p>Comprehensive NEET preparation program designed to help students crack the medical entrance exam with top ranks.</p>
                    
                    <h3>Course Details</h3>
                    <ul>
                        <li><strong>Duration:</strong> 1-2 Years</li>
                        <li><strong>Subjects:</strong> Physics, Chemistry, Biology</li>
                        <li><strong>Batch Size:</strong> Maximum 25 students</li>
                        <li><strong>Classes:</strong> 6 days a week</li>
                        <li><strong>Success Rate:</strong> 96%</li>
                    </ul>
                    
                    <h3>What's Included</h3>
                    <ul>
                        <li>Complete NCERT Coverage</li>
                        <li>Weekly Mock Tests</li>
                        <li>Previous Years Question Analysis</li>
                        <li>Doubt Clearing Sessions</li>
                        <li>Study Material & Books</li>
                        <li>Online Test Series</li>
                        <li>Personal Mentoring</li>
                    </ul>
                    
                    <div class="course-price-modal">₹45,000/year</div>
                    <button class="btn-submit" onclick="openModal('enroll')">Enroll Now</button>
                </div>
            `;
            break;
        case 'jee':
            content = `
                <h2>JEE Preparation Course</h2>
                <div class="course-modal-content">
                    <h3>Course Overview</h3>
                    <p>Advanced JEE preparation program focusing on IIT-level problem solving and conceptual understanding.</p>
                    
                    <h3>Course Details</h3>
                    <ul>
                        <li><strong>Duration:</strong> 1-2 Years</li>
                        <li><strong>Subjects:</strong> Physics, Chemistry, Mathematics</li>
                        <li><strong>Batch Size:</strong> Maximum 25 students</li>
                        <li><strong>Classes:</strong> 6 days a week</li>
                        <li><strong>Success Rate:</strong> 94%</li>
                    </ul>
                    
                    <h3>What's Included</h3>
                    <ul>
                        <li>IIT Level Problem Solving</li>
                        <li>Advanced Mathematics</li>
                        <li>Monthly All India Tests</li>
                        <li>Personal Mentoring</li>
                        <li>Crash Course Before Exam</li>
                        <li>Digital Learning Platform</li>
                        <li>Previous Years Analysis</li>
                    </ul>
                    
                    <div class="course-price-modal">₹50,000/year</div>
                    <button class="btn-submit" onclick="openModal('enroll')">Enroll Now</button>
                </div>
            `;
            break;
        case 'kcet':
            content = `
                <h2>KCET Preparation Course</h2>
                <div class="course-modal-content">
                    <h3>Course Overview</h3>
                    <p>Specialized Karnataka CET preparation with focus on state board integration and regional exam patterns.</p>
                    
                    <h3>Course Details</h3>
                    <ul>
                        <li><strong>Duration:</strong> 1 Year</li>
                        <li><strong>Subjects:</strong> PCM/PCB</li>
                        <li><strong>Batch Size:</strong> Maximum 30 students</li>
                        <li><strong>Classes:</strong> 5 days a week</li>
                        <li><strong>Success Rate:</strong> 97%</li>
                    </ul>
                    
                    <h3>What's Included</h3>
                    <ul>
                        <li>Karnataka CET Focused Curriculum</li>
                        <li>State Board Integration</li>
                        <li>Local Language Support</li>
                        <li>Regional Exam Patterns</li>
                        <li>Career Counseling</li>
                        <li>Affordable Fee Structure</li>
                        <li>Regular Mock Tests</li>
                    </ul>
                    
                    <div class="course-price-modal">₹35,000/year</div>
                    <button class="btn-submit" onclick="openModal('enroll')">Enroll Now</button>
                </div>
            `;
            break;
        case 'academic':
            content = `
                <h2>Academic Coaching (Class 8-12)</h2>
                <div class="course-modal-content">
                    <h3>Course Overview</h3>
                    <p>Comprehensive academic support for school students with focus on board exam preparation and concept building.</p>
                    
                    <h3>Course Details</h3>
                    <ul>
                        <li><strong>Duration:</strong> Full Academic Year</li>
                        <li><strong>Classes:</strong> 8th to 12th</li>
                        <li><strong>Batch Size:</strong> Maximum 20 students</li>
                        <li><strong>Classes:</strong> 5 days a week</li>
                        <li><strong>Success Rate:</strong> 98%</li>
                    </ul>
                    
                    <h3>What's Included</h3>
                    <ul>
                        <li>CBSE/State Board Coverage</li>
                        <li>Regular Assessments</li>
                        <li>Concept Building Focus</li>
                        <li>Project Guidance</li>
                        <li>Parent-Teacher Meetings</li>
                        <li>Scholarship Programs</li>
                        <li>Individual Attention</li>
                    </ul>
                    
                    <div class="course-price-modal">₹25,000/year</div>
                    <button class="btn-submit" onclick="openModal('enroll')">Enroll Now</button>
                </div>
            `;
            break;
    }
    
    modalBody.innerHTML = content;
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

closeModal.addEventListener('click', () => {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
});

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// Contact Form
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    
    // Show success message
    alert('Thank you for your message! We will contact you soon.');
    
    // Reset form
    this.reset();
});

// Back to Top Button
const backToTopBtn = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        backToTopBtn.style.display = 'flex';
    } else {
        backToTopBtn.style.display = 'none';
    }
});

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Add CSS for modal forms
const modalStyles = `
    .modal-form {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        margin-top: 1rem;
    }
    
    .modal-form input,
    .modal-form select,
    .modal-form textarea {
        padding: 1rem;
        border: 2px solid #eee;
        border-radius: 10px;
        font-size: 1rem;
        transition: border-color 0.3s ease;
    }
    
    .modal-form input:focus,
    .modal-form select:focus,
    .modal-form textarea:focus {
        outline: none;
        border-color: #4CAF50;
    }
    
    .course-modal-content h3 {
        color: #4CAF50;
        margin: 1.5rem 0 1rem 0;
    }
    
    .course-modal-content ul {
        margin-bottom: 1rem;
        padding-left: 1.5rem;
    }
    
    .course-modal-content li {
        margin-bottom: 0.5rem;
        line-height: 1.5;
    }
    
    .course-price-modal {
        font-size: 2rem;
        font-weight: bold;
        color: #4CAF50;
        text-align: center;
        margin: 2rem 0;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 10px;
    }
`;

// Add styles to head
const styleSheet = document.createElement('style');
styleSheet.textContent = modalStyles;
document.head.appendChild(styleSheet);

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    // Show first testimonial
    if (testimonials.length > 0) {
        showTestimonial(0);
    }
    
    // Add click handlers for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            scrollToSection(targetId);
        });
    });
});

// Admission Process Modal
function showAdmissionProcess() {
    const content = `
        <h2>Admission Process</h2>
        <div class="admission-steps">
            <div class="step">
                <h3>Step 1: Application</h3>
                <p>Fill out the online application form or visit our campus to submit the form in person.</p>
            </div>
            <div class="step">
                <h3>Step 2: Entrance Test</h3>
                <p>Appear for a simple entrance test to assess your current academic level.</p>
            </div>
            <div class="step">
                <h3>Step 3: Interview</h3>
                <p>Personal interview with our academic counselors to understand your goals and aspirations.</p>
            </div>
            <div class="step">
                <h3>Step 4: Enrollment</h3>
                <p>Complete the enrollment process by submitting required documents and fee payment.</p>
            </div>
        </div>
        
        <h3>Required Documents</h3>
        <ul>
            <li>Previous year mark sheets</li>
            <li>Transfer certificate (if applicable)</li>
            <li>Passport size photographs</li>
            <li>Aadhar card copy</li>
            <li>Parent/Guardian ID proof</li>
        </ul>
        
        <h3>Scholarship Information</h3>
        <p>We offer merit-based scholarships up to 50% fee waiver for deserving students. Economic assistance is also available for students from underprivileged backgrounds.</p>
        
        <button class="btn-submit" onclick="openModal('enroll')">Start Application</button>
    `;
    
    modalBody.innerHTML = content;
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Add admission process styles
const admissionStyles = `
    .admission-steps {
        margin: 2rem 0;
    }
    
    .step {
        background: #f8f9fa;
        padding: 1.5rem;
        margin-bottom: 1rem;
        border-radius: 10px;
        border-left: 4px solid #4CAF50;
    }
    
    .step h3 {
        color: #4CAF50;
        margin-bottom: 0.5rem;
    }
    
    .step p {
        color: #666;
        line-height: 1.6;
    }
`;

styleSheet.textContent += admissionStyles;