// Loading Screen
window.addEventListener('load', function() {
    const loader = document.getElementById('loader');
    setTimeout(() => {
        loader.style.opacity = '0';
        setTimeout(() => {
            loader.style.display = 'none';
        }, 500);
    }, 1500);
});

// Mobile Navigation
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Smooth Scrolling
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Header scroll effect
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.background = 'rgba(255, 255, 255, 0.98)';
        header.style.boxShadow = '0 2px 30px rgba(0, 0, 0, 0.15)';
    } else {
        header.style.background = 'rgba(255, 255, 255, 0.95)';
        header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    }
});

// Counter Animation
function animateCounters() {
    const counters = document.querySelectorAll('#students-count, #success-rate, #years-exp, #top-ranks');
    const targets = [5000, 95, 15, 500];
    
    counters.forEach((counter, index) => {
        const target = targets[index];
        const increment = target / 100;
        let current = 0;
        
        const updateCounter = () => {
            if (current < target) {
                current += increment;
                if (index === 1) { // Success rate
                    counter.textContent = Math.ceil(current) + '%';
                } else if (index === 2) { // Years
                    counter.textContent = Math.ceil(current) + '+';
                } else {
                    counter.textContent = Math.ceil(current) + '+';
                }
                setTimeout(updateCounter, 20);
            } else {
                if (index === 1) {
                    counter.textContent = target + '%';
                } else {
                    counter.textContent = target + '+';
                }
            }
        };
        updateCounter();
    });
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
            
            // Trigger counter animation when stats section is visible
            if (entry.target.classList.contains('stats')) {
                animateCounters();
            }
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.feature-card, .course-card, .faculty-card, .achievement-item, .stats');
    animatedElements.forEach(el => observer.observe(el));
});

// FAQ Functionality
document.addEventListener('DOMContentLoaded', () => {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all FAQ items
            faqItems.forEach(faq => faq.classList.remove('active'));
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
});

// Testimonial Slider
let currentTestimonial = 0;
const testimonials = document.querySelectorAll('.testimonial');

function showTestimonial(index) {
    testimonials.forEach(testimonial => testimonial.classList.remove('active'));
    testimonials[index].classList.add('active');
}

function nextTestimonial() {
    currentTestimonial = (currentTestimonial + 1) % testimonials.length;
    showTestimonial(currentTestimonial);
}

// Auto-rotate testimonials
setInterval(nextTestimonial, 5000);

// Modal Functionality
const modal = document.getElementById('modal');
const modalBody = document.getElementById('modal-body');
const closeModal = document.querySelector('.close');

function openModal(type) {
    let content = '';
    
    switch(type) {
        case 'neet':
            content = `
                <h2>NEET Preparation Course</h2>
                <div class="course-modal-content">
                    <h3>Course Overview</h3>
                    <p>Comprehensive NEET preparation program designed to help students crack the medical entrance exam with top ranks.</p>
                    
                    <h3>Course Details</h3>
                    <ul>
                        <li><strong>Duration:</strong> 1-2 Years</li>
                        <li><strong>Subjects:</strong> Physics, Chemistry, Biology</li>
                        <li><strong>Batch Size:</strong> Maximum 25 students</li>
                        <li><strong>Classes:</strong> 6 days a week</li>
                        <li><strong>Success Rate:</strong> 96%</li>
                    </ul>
                    
                    <h3>What's Included</h3>
                    <ul>
                        <li>Complete NCERT Coverage</li>
                        <li>Weekly Mock Tests</li>
                        <li>Previous Years Question Analysis</li>
                        <li>Doubt Clearing Sessions</li>
                        <li>Study Material & Books</li>
                        <li>Online Test Series</li>
                        <li>Personal Mentoring</li>
                    </ul>
                    
                    <button class="btn-submit" onclick="openEnrollment('NEET')">Enroll Now</button>
                </div>
            `;
            break;
        case 'jee':
            content = `
                <h2>JEE Preparation Course</h2>
                <div class="course-modal-content">
                    <h3>Course Overview</h3>
                    <p>Advanced JEE preparation program focusing on IIT-level problem solving and conceptual understanding.</p>
                    
                    <h3>Course Details</h3>
                    <ul>
                        <li><strong>Duration:</strong> 1-2 Years</li>
                        <li><strong>Subjects:</strong> Physics, Chemistry, Mathematics</li>
                        <li><strong>Batch Size:</strong> Maximum 25 students</li>
                        <li><strong>Classes:</strong> 6 days a week</li>
                        <li><strong>Success Rate:</strong> 94%</li>
                    </ul>
                    
                    <h3>What's Included</h3>
                    <ul>
                        <li>IIT Level Problem Solving</li>
                        <li>Advanced Mathematics</li>
                        <li>Monthly All India Tests</li>
                        <li>Personal Mentoring</li>
                        <li>Crash Course Before Exam</li>
                        <li>Digital Learning Platform</li>
                        <li>Previous Years Analysis</li>
                    </ul>
                    
                    <button class="btn-submit" onclick="openEnrollment('JEE')">Enroll Now</button>
                </div>
            `;
            break;
        case 'kcet':
            content = `
                <h2>KCET Preparation Course</h2>
                <div class="course-modal-content">
                    <h3>Course Overview</h3>
                    <p>Specialized Karnataka CET preparation with focus on state board integration and regional exam patterns.</p>
                    
                    <h3>Course Details</h3>
                    <ul>
                        <li><strong>Duration:</strong> 1 Year</li>
                        <li><strong>Subjects:</strong> PCM/PCB</li>
                        <li><strong>Batch Size:</strong> Maximum 30 students</li>
                        <li><strong>Classes:</strong> 5 days a week</li>
                        <li><strong>Success Rate:</strong> 97%</li>
                    </ul>
                    
                    <h3>What's Included</h3>
                    <ul>
                        <li>Karnataka CET Focused Curriculum</li>
                        <li>State Board Integration</li>
                        <li>Local Language Support</li>
                        <li>Regional Exam Patterns</li>
                        <li>Career Counseling</li>
                        <li>Affordable Fee Structure</li>
                        <li>Regular Mock Tests</li>
                    </ul>
                    
                    <button class="btn-submit" onclick="openEnrollment('KCET')">Enroll Now</button>
                </div>
            `;
            break;
    }
    
    modalBody.innerHTML = content;
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function openEnrollment(course) {
    const content = `
        <h2>Enroll for ${course} Course</h2>
        <form id="enrollmentForm" class="modal-form">
            <input type="text" id="studentName" placeholder="Student Name" required>
            <input type="email" id="studentEmail" placeholder="Email Address" required>
            <input type="tel" id="studentPhone" placeholder="Phone Number" required>
            <textarea id="studentMessage" placeholder="Any specific requirements or questions?" rows="3"></textarea>
            <button type="button" class="btn-submit" onclick="submitEnrollment('${course}')">Submit Application</button>
        </form>
    `;
    
    modalBody.innerHTML = content;
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

async function submitEnrollment(course) {
    const name = document.getElementById('studentName').value;
    const email = document.getElementById('studentEmail').value;
    const phone = document.getElementById('studentPhone').value;
    const message = document.getElementById('studentMessage').value;
    
    if (!name || !email || !phone) {
        alert('Please fill in all required fields.');
        return;
    }
    
    const formData = {
        name: name,
        email: email,
        phone: phone,
        course: course,
        message: message
    };
    
    const result = await submitToSheets(formData, 'Enrollments');
    
    if (result.success) {
        alert(`Thank you for enrolling in ${course}! We will contact you soon.`);
        closeModalFunc();
        document.getElementById('enrollmentForm').reset();
    } else {
        alert('There was an error processing your enrollment. Please try again.');
    }
}

function closeModalFunc() {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

closeModal.addEventListener('click', closeModalFunc);

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModalFunc();
    }
});

// Contact Form
document.getElementById('contactForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        name: this.name.value,
        email: this.email.value,
        phone: this.phone.value,
        message: this.message.value
    };
    
    const result = await submitToSheets(formData, 'Contact_Forms');
    
    if (result.success) {
        alert('Thank you for your message! We will get back to you soon.');
        this.reset();
    } else {
        alert('There was an error submitting your form. Please try again.');
    }
});

// Back to Top Button
const backToTopBtn = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        backToTopBtn.style.display = 'flex';
    } else {
        backToTopBtn.style.display = 'none';
    }
});

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Sticky Enroll Button
const stickyEnroll = document.getElementById('stickyEnroll');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 800) {
        stickyEnroll.classList.add('show');
    } else {
        stickyEnroll.classList.remove('show');
    }
});

// Enhanced scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const scrollObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    // Show first testimonial
    if (testimonials.length > 0) {
        showTestimonial(0);
    }
    
    // Add click handlers for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            scrollToSection(targetId);
        });
    });
    
    // Initialize scroll animations
    document.querySelectorAll('.achievement-item, .feature-card, .course-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
        scrollObserver.observe(el);
    });
});

// Load map function
function loadMap() {
    const placeholder = document.querySelector('.map-placeholder');
    const container = document.getElementById('mapContainer');
    const frame = document.getElementById('mapFrame');
    
    // Hide placeholder and show map
    placeholder.style.display = 'none';
    container.style.display = 'block';
    
    // Load map with actual coordinates for Kudachi, Karnataka
    frame.src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3847.5!2d74.6!3d16.2!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sKudachi%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1234567890!5m2!1sen!2sin';
}

// FAQ Category Switching
document.addEventListener('DOMContentLoaded', () => {
    const categoryButtons = document.querySelectorAll('.faq-category');
    const categoryContents = document.querySelectorAll('.faq-category-content');
    const faqCards = document.querySelectorAll('.faq-card');
    
    // Category switching
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.dataset.category;
            
            // Update active category button
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            // Update active content
            categoryContents.forEach(content => content.classList.remove('active'));
            document.getElementById(category).classList.add('active');
        });
    });
    
    // FAQ card toggle
    faqCards.forEach(card => {
        const header = card.querySelector('.faq-header');
        header.addEventListener('click', () => {
            const isActive = card.classList.contains('active');
            
            // Close all cards
            faqCards.forEach(c => c.classList.remove('active'));
            
            // Open clicked card if it wasn't active
            if (!isActive) {
                card.classList.add('active');
            }
        });
    });
});