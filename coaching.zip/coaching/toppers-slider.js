// Toppers Slider Functionality
let currentSlideIndex = 0;
const totalSlides = 2;

function slideToppers(direction) {
    const track = document.getElementById('toppersTrack');
    const dots = document.querySelectorAll('.dot');
    
    currentSlideIndex += direction;
    
    if (currentSlideIndex >= totalSlides) {
        currentSlideIndex = 0;
    } else if (currentSlideIndex < 0) {
        currentSlideIndex = totalSlides - 1;
    }
    
    track.style.transform = `translateX(-${currentSlideIndex * 100}%)`;
    
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlideIndex);
    });
}

function currentSlide(slideIndex) {
    const track = document.getElementById('toppersTrack');
    const dots = document.querySelectorAll('.dot');
    
    currentSlideIndex = slideIndex - 1;
    
    track.style.transform = `translateX(-${currentSlideIndex * 100}%)`;
    
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlideIndex);
    });
}

setInterval(() => {
    slideToppers(1);
}, 5000);