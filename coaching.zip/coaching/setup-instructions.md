# Google Sheets Integration Setup

## Step 1: Create Google Spreadsheet
1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Name it "Golden Bage Classes - Student Data"
4. Copy the spreadsheet ID from the URL (the long string between `/d/` and `/edit`)

## Step 2: Setup Google Apps Script
1. Go to [Google Apps Script](https://script.google.com)
2. Create a new project
3. Replace the default code with the content from `google-apps-script.js`
4. Replace `YOUR_SPREADSHEET_ID` with your actual spreadsheet ID
5. Save the project

## Step 3: Deploy Web App
1. Click "Deploy" > "New deployment"
2. Choose type: "Web app"
3. Execute as: "Me"
4. Who has access: "Anyone"
5. Click "Deploy"
6. Copy the Web App URL

## Step 4: Update Website Configuration
1. Open `sheets-config.js`
2. Replace `YOUR_SCRIPT_ID` with the Web App URL you copied
3. Save the file

## Step 5: Test the Integration
1. Open your website
2. Fill out the contact form or enrollment form
3. Check your Google Spreadsheet for new entries

## Benefits of Google Sheets Integration
- ✅ Free to use
- ✅ No server setup required
- ✅ Automatic data backup
- ✅ Easy to share with team
- ✅ Built-in data analysis tools
- ✅ Mobile accessible
- ✅ Real-time updates

## Data Structure
### Contact_Forms Sheet
- Timestamp
- Name
- Email
- Phone
- Message

### Enrollments Sheet
- Timestamp
- Name
- Email
- Phone
- Course
- Message