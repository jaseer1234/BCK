// Google Apps Script code to paste in script.google.com
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const sheetName = data.sheet;
    const formData = data.data;
    
    // Open the spreadsheet (replace with your spreadsheet ID)
    const ss = SpreadsheetApp.openById('YOUR_SPREADSHEET_ID');
    
    let sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      
      // Add headers based on sheet type
      if (sheetName === 'Contact_Forms') {
        sheet.getRange(1, 1, 1, 5).setValues([['Timestamp', 'Name', 'Email', 'Phone', 'Message']]);
      } else if (sheetName === 'Enrollments') {
        sheet.getRange(1, 1, 1, 6).setValues([['Timestamp', 'Name', 'Email', 'Phone', 'Course', 'Message']]);
      }
    }
    
    // Prepare row data
    const timestamp = new Date();
    let rowData;
    
    if (sheetName === 'Contact_Forms') {
      rowData = [timestamp, formData.name, formData.email, formData.phone, formData.message];
    } else if (sheetName === 'Enrollments') {
      rowData = [timestamp, formData.name, formData.email, formData.phone, formData.course, formData.message];
    }
    
    // Add the data to the sheet
    sheet.appendRow(rowData);
    
    return ContentService
      .createTextOutput(JSON.stringify({success: true}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({success: false, error: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}